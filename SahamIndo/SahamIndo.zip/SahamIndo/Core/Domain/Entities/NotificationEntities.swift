//
//  NotificationEntities.swift
//  StockAppTryNew
//
//  Created by Surya on 16/06/26.
//

import Foundation

// MARK: - StockAlert (persisted)

struct StockAlert: Identifiable, Codable {
    var id: UUID = UUID()
    var date: Date
    var symbol: String
    var stockName: String?
    var sector: String?
    var alertType: AlertType
    var score: Double
    var aiSummary: String
    var isRead: Bool = false

    enum AlertType: String, Codable {
        case strongBuy  = "strongBuy"
        case strongSell = "strongSell"
    }
}

// MARK: - Chat

enum MessageRole: String, Codable {
    case user      = "user"
    case assistant = "assistant"
}

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let role: MessageRole
    var content: String
    let timestamp: Date = Date()
}

struct ChatHistoryItem: Codable {
    let role: String
    let content: String
}

// MARK: - CacheState (UI feedback)

enum CacheState: Equatable {
    case live
    case cached(age: String)
    case noData
}
