//
//  ChartViewModelProtocol.swift
//  StockAppTryNew
//
//  Abstraction so the reusable chart components (ChartCanvasView,
//  XAxisAnimatedLabels, TimeRangeSelectorView) can be driven by any
//  view model that exposes a price/value series — not just
//  StockDetailViewModel. PortfolioChartViewModel conforms to this too,
//  so the same chart UI can power the Portfolio summary chart.
//

import Foundation

@MainActor
protocol ChartViewModelProtocol: ObservableObject {

    var dataPoints:    [StockDataPoint] { get }
    var selectedRange: TimeRange        { get set }
    var isLoading:     Bool             { get }

    var minPrice:    Double { get }
    var maxPrice:    Double { get }
    var startPrice:  Double { get }
    var latestPrice: Double { get }

    static var oneDayTotalSlots:  Int { get }
    static var oneDayOpenMinutes: Int { get }

    func oneDaySlotIndex(for date: Date) -> Int
    func fetchChartData() async
}
