//
//  StockDetailViewModel.swift
//  StockAppTryNew
//
//  Created by Surya on 16/06/26.
//

import SwiftUI
import Combine

@MainActor
final class StockDetailViewModel: ObservableObject, ChartViewModelProtocol {

    // MARK: - Published State

    @Published private(set) var dataPoints:   [StockDataPoint] = []
    @Published private(set) var detail:       StockDetail?
    @Published private(set) var isLoading:    Bool             = false
    @Published private(set) var errorMessage: String?
    @Published var selectedRange: TimeRange = .oneDay

    let item: PortfolioItem

    // MARK: - Computed

    var minPrice:    Double { dataPoints.map(\.close).min() ?? 0 }
    var maxPrice:    Double { dataPoints.map(\.close).max() ?? 0 }
    var startPrice:  Double { dataPoints.first?.close ?? 0 }
    var latestPrice: Double { dataPoints.last?.close  ?? 0 }
    var changeAmount:  Double { latestPrice - startPrice }
    var changePercent: Double { startPrice != 0 ? (changeAmount / startPrice) * 100 : 0 }
    var isPositive:    Bool   { latestPrice >= startPrice }

    // MARK: - 1D Slot Variables (Dynamically set based on data)

    @Published private(set) var oneDayTotalSlots = 87
    private var oneDayOpenDate: Date?

    // MARK: - Dependencies

    private let fetchChartUseCase: FetchChartDataUseCase
    private let detailRepository:  StockDetailRepositoryProtocol

    // MARK: - Init

    init(item: PortfolioItem,
         fetchChartUseCase: FetchChartDataUseCase,
         detailRepository:  StockDetailRepositoryProtocol) {
        self.item              = item
        self.fetchChartUseCase = fetchChartUseCase
        self.detailRepository  = detailRepository
    }

    // MARK: - Public Actions

    func fetchChartData() async {
        isLoading    = true
        errorMessage = nil
        let (points, state) = await fetchChartUseCase.execute(symbol: item.symbol,
                                                               range: selectedRange)
        dataPoints = selectedRange == .oneDay ? normalizeToSlots(points) : points
        if dataPoints.isEmpty {
            errorMessage = "Tidak ada data untuk \(item.symbol) (\(selectedRange.rawValue))"
        }
        isLoading = false
    }

    func fetchDetail() async {
        detail = try? await detailRepository.fetchDetail(symbol: item.symbol)
    }

    func oneDaySlotIndex(for date: Date) -> Int {
        guard let openDate = oneDayOpenDate else { return 0 }
        let minutes = date.timeIntervalSince(openDate) / 60.0
        return max(0, min(Int(minutes / 5.0), oneDayTotalSlots - 1))
    }

    // MARK: - Private

    private func normalizeToSlots(_ candles: [StockDataPoint]) -> [StockDataPoint] {
        guard !candles.isEmpty else { return [] }
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Jakarta")!
        let now = Date()
        
        let openDate = candles[0].date
        let openHour = cal.component(.hour, from: openDate)
        
        // Detect US Market (typically opens 20:30 or 21:30 WIB)
        let isUS = openHour >= 19 || openHour < 5
        let totalSlots = isUS ? 79 : 87
        
        self.oneDayTotalSlots = totalSlots
        self.oneDayOpenDate   = openDate
        
        var slots: [StockDataPoint?] = Array(repeating: nil, count: totalSlots)

        for candle in candles {
            let idx = oneDaySlotIndex(for: candle.date)
            guard idx >= 0, idx < totalSlots else { continue }
            slots[idx] = candle
        }

        let currentSlotIdx: Int
        if isUS {
            let hoursSinceOpen = now.timeIntervalSince(openDate) / 3600.0
            if hoursSinceOpen >= 0 && hoursSinceOpen < 16 {
                let minutes = now.timeIntervalSince(openDate) / 60.0
                currentSlotIdx = max(0, min(Int(minutes / 5.0), totalSlots - 1))
            } else {
                currentSlotIdx = totalSlots - 1
            }
        } else {
            if cal.isDate(openDate, inSameDayAs: now) {
                let minutes = now.timeIntervalSince(openDate) / 60.0
                currentSlotIdx = max(0, min(Int(minutes / 5.0), totalSlots - 1))
            } else {
                currentSlotIdx = totalSlots - 1
            }
        }

        for i in stride(from: 1, through: currentSlotIdx, by: 1) {
            if slots[i] == nil, let prev = slots[i - 1] {
                let slotDate = openDate.addingTimeInterval(TimeInterval(i * 5 * 60))
                slots[i] = StockDataPoint(date: slotDate, close: prev.close, open: prev.close,
                                           high: prev.close, low: prev.close, volume: 0)
            }
        }
        return slots[0...currentSlotIdx].compactMap { $0 }
    }
}
