////
////  HomeView.swift
////  StockAppTryNew
////
////  Created by Surya on 16/06/26.
////
//
import SwiftUI
//
//struct HomeView: View {
//
//    @EnvironmentObject private var portfolioVM: PortfolioViewModel
//    @EnvironmentObject private var homeVM:      HomeViewModel
//    @EnvironmentObject private var notifVM:     NotificationViewModel
//    @EnvironmentObject private var router:      Router
//
//
//    var body: some View {
//        ScrollView {
//            VStack(spacing: 0) {
//                PortfolioSummaryCardView(
//                    summary:          portfolioVM.summary,
//                    items:            portfolioVM.items,
//                    holdings:         portfolioVM.holdings,
//                )
//                .padding(.top, 12)
//                .padding(.bottom, 20)
//
//                AIInsightCardView(chips: homeVM.insightChips)
//                    .padding(.vertical, 12)
//
//                sectionHeader("20 Bluechip Stock's")
//
//                Divider()
//                    .frame(height: 1.5)
//                    .background(Color.PrimaryYellow)
//                    .padding(.horizontal)
//
//                StockListView(
//                    items:  homeVM.stocks,
//                    onTap:  { router.push(.stockDetail($0)) }
//                )
//            }
//        }
//        .background(Color.DarkPurpleAppBackground.ignoresSafeArea())
//        .toolbar(.hidden, for: .navigationBar)
//        .safeAreaInset(edge: .top) { topBar }
//        .task {
//            await portfolioVM.fetchData()
//            await homeVM.loadStocks(holdings: portfolioVM.holdings)
//            await homeVM.loadInsights()
//        }
//        .task { await notifVM.checkForAlerts() }
//        .onAppear { configureSegmentedAppearance() }
//    }
//
//    // MARK: - Sub-views
//
//    private var topBar: some View {
//        HStack {
//            HStack(spacing: 0) {
//                Image("logo_icon")
//                    .renderingMode(.template)
//                    .resizable().scaledToFit()
//                    .foregroundColor(Color.PrimaryYellow)
//                Image("logo_teks")
//                    .renderingMode(.template)
//                    .resizable().scaledToFit()
//                    .foregroundColor(Color(UIColor.label))
//            }
//            .frame(height: 36)
//            Spacer()
//            NotificationButton(unreadCount: notifVM.unreadCount) {
//                router.push(.notification)
//            }
//        }
//        .padding(.horizontal)
//        .padding(.vertical, 8)
//        .background(Color.DarkPurpleAppBackground)
//    }
//
//    private func sectionHeader(_ title: String) -> some View {
//        HStack {
//            Text(title)
//                .font(Font.title2).fontWeight(.bold)
//                .foregroundColor(.primary)
//            Spacer()
//        }
//        .padding(.horizontal)
//        .padding(.bottom, 6)
//    }
//
//    private func configureSegmentedAppearance() {
//        UISegmentedControl.appearance().selectedSegmentTintColor = UIColor(Color.PrimaryYellow)
//        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.black],           for: .selected)
//        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.secondaryLabel], for: .normal)
//    }
//}
//
//// MARK: - NotificationButton
//
//struct NotificationButton: View {
//    let unreadCount: Int
//    let action: () -> Void
//    var body: some View {
//        Button(action: action) {
//            ZStack(alignment: .topTrailing) {
//                Image(systemName: "bell.fill")
//                    .font(Font.title3)
//                    .foregroundColor(.primary)
//                if unreadCount > 0 {
//                    ZStack {
//                        Circle().fill(Color.LossRed).frame(width: 16, height: 16)
//                        Text(unreadCount > 9 ? "9+" : "\(unreadCount)")
//                            .font(Font.caption2).foregroundColor(.SurfaceWhite)
//                    }
//                    .offset(x: 6, y: -6)
//                }
//            }
//        }
//    }
//}
//
//// MARK: - StockListView
//
struct StockListView: View {
    let items: [PortfolioItem]
    let onTap: (PortfolioItem) -> Void
    var body: some View {
        LazyVStack(spacing: 0) {
            ForEach(items) { item in
                VStack(spacing: 0) {
                    StockRowView(stock: item).padding(.horizontal, 16).padding(.vertical, 6)
                    Divider().padding(.horizontal, 16)
                }
                .contentShape(Rectangle())
                .onTapGesture { onTap(item) }
            }
        }
    }
}
