//
//  MiniSparklineView.swift
//  StockAppTryNew
//
//  Created by Surya on 16/06/26.
//

import SwiftUI
import Combine

// MARK: - MiniSparklineViewModel

@MainActor
final class MiniSparklineViewModel: ObservableObject {
    @Published private(set) var dataPoints: [StockDataPoint] = []

    private let chartRepository: ChartRepositoryProtocol

    init(chartRepository: ChartRepositoryProtocol) {
        self.chartRepository = chartRepository
    }

    func fetch(symbol: String) async {
        let (points, _) = await chartRepository.fetchCandles(symbol: symbol, range: .oneDay)
        dataPoints = normalizeToSlots(points)
    }

    // MARK: - Slot helpers (mirrors StockDetailViewModel exactly)

    // Total slot aktif bursa IDX per hari:
    //   Senin–Kamis: 09:00–12:00 (36 slot) + 13:30–15:55 (30 slot) + slot 15:55 = 67 slot
    //   Jumat      : 09:00–11:20 (28 slot) + 13:55–15:55 (25 slot) + slot 15:55 = 54 slot
    // StockDetailViewModel memakai konstanta tunggal 87 slot dengan mapping
    // "menit aktif" → slot. Kita gunakan pendekatan yang sama supaya X-koordinat identik.

    @Published private(set) var totalSlots: Int = 87
    private var openDate: Date?

    func slotIndex(for date: Date) -> Int {
        guard let open = openDate else { return 0 }
        let minutes = date.timeIntervalSince(open) / 60.0
        return max(0, min(Int(minutes / 5.0), totalSlots - 1))
    }

    private func normalizeToSlots(_ candles: [StockDataPoint]) -> [StockDataPoint] {
        guard !candles.isEmpty else { return [] }
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Jakarta")!
        let now = Date()
        
        let startCandle = candles[0].date
        let openHour = cal.component(.hour, from: startCandle)
        let isUS = openHour >= 19 || openHour < 5
        let tSlots = isUS ? 79 : 87
        
        self.totalSlots = tSlots
        self.openDate = startCandle
        
        var slots: [StockDataPoint?] = Array(repeating: nil, count: tSlots)

        for candle in candles {
            let idx = slotIndex(for: candle.date)
            guard idx >= 0, idx < tSlots else { continue }
            slots[idx] = candle
        }

        let currentSlotIdx: Int
        if isUS {
            let hoursSinceOpen = now.timeIntervalSince(startCandle) / 3600.0
            if hoursSinceOpen >= 0 && hoursSinceOpen < 16 {
                let minutes = now.timeIntervalSince(startCandle) / 60.0
                currentSlotIdx = max(0, min(Int(minutes / 5.0), tSlots - 1))
            } else {
                currentSlotIdx = tSlots - 1
            }
        } else {
            if cal.isDate(startCandle, inSameDayAs: now) {
                let minutes = now.timeIntervalSince(startCandle) / 60.0
                currentSlotIdx = max(0, min(Int(minutes / 5.0), tSlots - 1))
            } else {
                currentSlotIdx = tSlots - 1
            }
        }

        for i in stride(from: 1, through: currentSlotIdx, by: 1) {
            if slots[i] == nil, let prev = slots[i - 1] {
                let slotDate = startCandle.addingTimeInterval(TimeInterval(i * 5 * 60))
                slots[i] = StockDataPoint(date: slotDate, close: prev.close, open: prev.close,
                                          high: prev.close, low: prev.close, volume: 0)
            }
        }
        return slots[0...currentSlotIdx].compactMap { $0 }
    }
}

// MARK: - MiniSparklineView

struct MiniSparklineView: View {

    let symbol:     String
    let isPositive: Bool

    @StateObject private var vm: MiniSparklineViewModel

    private let green = Color.ProfitGreen
    private let red   = Color.LossRed

    init(symbol: String, isPositive: Bool) {
        self.symbol     = symbol
        self.isPositive = isPositive
        // Inject via DI container
        _vm = StateObject(wrappedValue: MiniSparklineViewModel(
            chartRepository: DIContainer.shared.chartRepository
        ))
    }

    var body: some View {
        let points      = vm.dataPoints
        let totalSlots  = vm.totalSlots
        // Precompute di sini (konteks @MainActor) agar Canvas closure
        // yang nonisolated tidak perlu memanggil vm.slotIndex langsung.
        let slotIndices = points.map { vm.slotIndex(for: $0.date) }

        Canvas { ctx, size in
            guard points.count > 1 else { return }
            let closes   = points.map(\.close)
            let startVal = closes[0]
            let minVal   = closes.min()!
            let maxVal   = closes.max()!
            let range    = max(maxVal - minVal, 1)
            let w = size.width; let h = size.height; let padV: CGFloat = 4
            let usableH  = h - padV * 2

            func xFor(_ i: Int) -> CGFloat {
                CGFloat(slotIndices[i]) / CGFloat(totalSlots - 1) * w
            }
            func yFor(_ v: Double) -> CGFloat { padV + usableH * (1 - (v - minVal) / range) }

            let startY = yFor(startVal)

            func buildArea(closeY: CGFloat) -> Path {
                var p = Path()
                p.move(to: CGPoint(x: xFor(0), y: closeY))
                for i in 0..<closes.count {
                    let x = xFor(i); let y = yFor(closes[i])
                    if i == 0 { p.addLine(to: CGPoint(x: x, y: y)) }
                    else {
                        let px = xFor(i - 1); let py = yFor(closes[i - 1])
                        p.addCurve(to: CGPoint(x: x, y: y),
                                   control1: CGPoint(x: px + (x-px)*0.5, y: py),
                                   control2: CGPoint(x: px + (x-px)*0.5, y: y))
                    }
                }
                p.addLine(to: CGPoint(x: xFor(closes.count - 1), y: closeY))
                p.closeSubpath(); return p
            }

            func buildLine() -> Path {
                var p = Path()
                for i in 0..<closes.count {
                    let x = xFor(i); let y = yFor(closes[i])
                    if i == 0 { p.move(to: CGPoint(x: x, y: y)) }
                    else {
                        let px = xFor(i-1); let py = yFor(closes[i-1])
                        p.addCurve(to: CGPoint(x: x, y: y),
                                   control1: CGPoint(x: px+(x-px)*0.5, y: py),
                                   control2: CGPoint(x: px+(x-px)*0.5, y: y))
                    }
                }
                return p
            }

            let lineStyle = StrokeStyle(lineWidth: 1.2, lineCap: .round, lineJoin: .round)
            let line = buildLine()

            ctx.drawLayer { layer in
                layer.clip(to: Path(CGRect(x: 0, y: 0, width: w, height: startY)))
                layer.fill(buildArea(closeY: startY), with: .linearGradient(
                    Gradient(stops: [.init(color: green.opacity(0.18), location: 0),
                                     .init(color: green.opacity(0.06), location: 1)]),
                    startPoint: CGPoint(x: 0, y: 0), endPoint: CGPoint(x: 0, y: startY)))
                layer.stroke(line, with: .color(green), style: lineStyle)
            }
            ctx.drawLayer { layer in
                layer.clip(to: Path(CGRect(x: 0, y: startY, width: w, height: h - startY)))
                layer.fill(buildArea(closeY: h), with: .linearGradient(
                    Gradient(stops: [.init(color: red.opacity(0.18), location: 0),
                                     .init(color: red.opacity(0.04), location: 1)]),
                    startPoint: CGPoint(x: 0, y: startY), endPoint: CGPoint(x: 0, y: h)))
                layer.stroke(line, with: .color(red), style: lineStyle)
            }

            let lastY      = yFor(closes.last!)
            let lastColor  = closes.last! >= startVal ? green : red
            var dash = Path()
            dash.move(to: CGPoint(x: 0, y: lastY)); dash.addLine(to: CGPoint(x: w, y: lastY))
            ctx.stroke(dash, with: .color(lastColor.opacity(0.5)),
                       style: StrokeStyle(lineWidth: 0.75, dash: [3, 3]))
            let dotX = xFor(closes.count - 1); let dotR: CGFloat = 2.5
            ctx.fill(Path(ellipseIn: CGRect(x: dotX-dotR, y: lastY-dotR, width: dotR*2, height: dotR*2)),
                     with: .color(lastColor))
        }
        .task(id: symbol) { await vm.fetch(symbol: symbol) }
        .onReceive(Timer.publish(every: 5 * 60, on: .main, in: .common).autoconnect()) { _ in
            Task { await vm.fetch(symbol: symbol) }
        }
    }
}
