//
//  NotificationViewModel.swift
//  StockAppTryNew
//
//  Created by Surya on 16/06/26.
//

import SwiftUI
import UserNotifications
import Combine

@MainActor
final class NotificationViewModel: ObservableObject {

    @Published private(set) var alerts:     [StockAlert] = []
    @Published private(set) var isChecking: Bool         = false

    var unreadCount: Int { alerts.filter { !$0.isRead }.count }

    private let detailRepository: StockDetailRepositoryProtocol
    private let alertRepository:  AlertRepositoryProtocol
    private let persistence       = UserDefaultsAlertStore()

    private static let watchSymbols = [
        "BBCA","BBRI","BMRI","BBNI","TLKM",
        "ASII","UNVR","ADRO","GGRM","KLBF",
        "ANTM","PGAS","ICBP","INDF","UNTR",
        "PTBA","MEDC","BRIS","AMRT","MDKA"
    ]
    private let bullishThreshold: Double = 75.0
    private let bearishThreshold: Double = 30.0

    init(detailRepository: StockDetailRepositoryProtocol,
         alertRepository:  AlertRepositoryProtocol) {
        self.detailRepository = detailRepository
        self.alertRepository  = alertRepository
        alerts = persistence.load()
    }

    func checkForAlerts() async {
        guard !isChecking else { return }
        if let lastCheck = persistence.lastCheckDate(),
           Date().timeIntervalSince(lastCheck) < 3600 { return }

        isChecking = true
        await requestPermission()

        let alertedToday = Set(alerts.filter { Calendar.current.isDateInToday($0.date) }.map { $0.symbol })

        for symbol in Self.watchSymbols where !alertedToday.contains(symbol) {
            guard let detail = try? await detailRepository.fetchDetail(symbol: symbol) else { continue }
            let isBuy  = detail.sentimentScore >= bullishThreshold && detail.sentiment == .recommended
            let isSell = detail.sentimentScore <= bearishThreshold && detail.sentiment == .caution
            guard isBuy || isSell else { continue }

            let alert = StockAlert(date: Date(), symbol: detail.symbol, stockName: detail.name,
                                   sector: detail.sector, alertType: isBuy ? .strongBuy : .strongSell,
                                   score: detail.sentimentScore, aiSummary: detail.aiSummary)
            alerts.insert(alert, at: 0)
            await schedulePush(for: alert)
        }

        if alerts.count > 50 { alerts = Array(alerts.prefix(50)) }
        persistence.save(alerts)
        persistence.setLastCheckDate(Date())
        isChecking = false
    }

    func markRead(_ id: UUID) {
        guard let idx = alerts.firstIndex(where: { $0.id == id }) else { return }
        alerts[idx].isRead = true
        persistence.save(alerts)
    }

    func markAllRead() {
        alerts = alerts.map { var a = $0; a.isRead = true; return a }
        persistence.save(alerts)
    }

    func clearAll() {
        alerts = []
        persistence.save(alerts)
    }

    private func requestPermission() async {
        _ = try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .badge, .sound])
    }

    private func schedulePush(for alert: StockAlert) async {
        let content   = UNMutableNotificationContent()
        content.title = alert.alertType == .strongBuy ? "📈 Sinyal Bullish Kuat" : "📉 Sinyal Bearish Kuat"
        let name      = alert.stockName ?? alert.symbol
        content.body  = "\(alert.symbol) (\(name)) — Score \(Int(alert.score))\n\(String(alert.aiSummary.prefix(100)))…"
        content.sound = .default
        let trigger   = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request   = UNNotificationRequest(identifier: alert.id.uuidString, content: content, trigger: trigger)
        try? await UNUserNotificationCenter.current().add(request)
    }
}

// MARK: - UserDefaultsAlertStore (private persistence helper)

private struct UserDefaultsAlertStore {
    private let alertsKey    = "stock_alerts_v1"
    private let lastCheckKey = "stock_alerts_last_check"
    private let defaults     = UserDefaults.standard

    func load() -> [StockAlert] {
        guard let data    = defaults.data(forKey: alertsKey),
              let decoded = try? JSONDecoder().decode([StockAlert].self, from: data) else { return [] }
        return decoded
    }

    func save(_ alerts: [StockAlert]) {
        guard let data = try? JSONEncoder().encode(alerts) else { return }
        defaults.set(data, forKey: alertsKey)
    }

    func lastCheckDate() -> Date? { defaults.object(forKey: lastCheckKey) as? Date }
    func setLastCheckDate(_ date: Date) { defaults.set(date, forKey: lastCheckKey) }
}
